CREATE TABLE dim_customers (
    customerid  INTEGER NOT NULL,
    companyname VARCHAR2(50),
    city        VARCHAR2(20),
    country     VARCHAR2(20)
);

ALTER TABLE dim_customers ADD CONSTRAINT customers_pk PRIMARY KEY ( customerid );

CREATE TABLE dim_employees (
    employeeid   INTEGER NOT NULL,
    employeename VARCHAR2(30),
    title        VARCHAR2(30),
    city         VARCHAR2(30),
    country      VARCHAR2(25)
);

ALTER TABLE dim_employees ADD CONSTRAINT employees_pk PRIMARY KEY ( employeeid );

CREATE TABLE dim_products (
    productid   INTEGER NOT NULL,
    productname VARCHAR2(50),
    unitprice   NUMBER,
    category    VARCHAR2(25)
);

ALTER TABLE dim_products ADD CONSTRAINT products_pk PRIMARY KEY ( productid );

CREATE TABLE dim_shippers (
    shipperid   INTEGER NOT NULL,
    companyname VARCHAR2(25)
);

ALTER TABLE dim_shippers ADD CONSTRAINT shippers_pk PRIMARY KEY ( shipperid );

CREATE TABLE dim_time (
    timeid INTEGER NOT NULL,
    month  VARCHAR2(2),
    year   VARCHAR2(4)
);

ALTER TABLE dim_time ADD CONSTRAINT tiempoid_pk PRIMARY KEY ( timeid );

CREATE TABLE fact_orders (
    customerid INTEGER NOT NULL,
    employeeid INTEGER NOT NULL,
    timeid     INTEGER NOT NULL,
    shipperid  INTEGER NOT NULL,
    productid  INTEGER NOT NULL,
    quantity   INTEGER,
    totalsold  NUMBER(10, 2)
);

CREATE TABLE stage_customers (
    customerid VARCHAR2(10),
    id         INTEGER
);

ALTER TABLE fact_orders
    ADD CONSTRAINT table_17_customers_fk FOREIGN KEY ( customerid )
        REFERENCES dim_customers ( customerid );

ALTER TABLE fact_orders
    ADD CONSTRAINT table_17_employees_fk FOREIGN KEY ( employeeid )
        REFERENCES dim_employees ( employeeid );

ALTER TABLE fact_orders
    ADD CONSTRAINT table_17_products_fk FOREIGN KEY ( productid )
        REFERENCES dim_products ( productid );

ALTER TABLE fact_orders
    ADD CONSTRAINT table_17_shippers_fk FOREIGN KEY ( shipperid )
        REFERENCES dim_shippers ( shipperid );

ALTER TABLE fact_orders
    ADD CONSTRAINT table_17_tiempoid_fk FOREIGN KEY ( timeid )
        REFERENCES dim_time ( timeid );