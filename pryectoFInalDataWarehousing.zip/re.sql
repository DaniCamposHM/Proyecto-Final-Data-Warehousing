BEGIN
   EXECUTE IMMEDIATE 'DROP TABLE orders CASCADE CONSTRAINTS';
   EXECUTE IMMEDIATE 'DROP TABLE stage_customers CASCADE CONSTRAINTS';
   EXECUTE IMMEDIATE 'DROP TABLE time CASCADE CONSTRAINTS';
   EXECUTE IMMEDIATE 'DROP TABLE products CASCADE CONSTRAINTS';
   EXECUTE IMMEDIATE 'DROP TABLE shippers CASCADE CONSTRAINTS';
   EXECUTE IMMEDIATE 'DROP TABLE customers CASCADE CONSTRAINTS';
   EXECUTE IMMEDIATE 'DROP TABLE employees CASCADE CONSTRAINTS';
EXCEPTION
   WHEN OTHERS THEN
      IF SQLCODE != -942 THEN
         RAISE;
      END IF;
END;
/

-- Crear tablas de nuevo
CREATE TABLE customers (
    customerid  INTEGER NOT NULL,
    companyname VARCHAR2(50),
    city        VARCHAR2(20),
    country     VARCHAR2(20)
);

ALTER TABLE customers ADD CONSTRAINT customers_pk PRIMARY KEY ( customerid );

CREATE TABLE employees (
    employeeid   INTEGER NOT NULL,
    employeename VARCHAR2(30),
    title        VARCHAR2(30),
    city         VARCHAR2(30),
    country      VARCHAR2(25)
);

ALTER TABLE employees ADD CONSTRAINT employees_pk PRIMARY KEY ( employeeid );

CREATE TABLE orders (
    customerid INTEGER NOT NULL,
    employeeid INTEGER NOT NULL,
    timeid     INTEGER NOT NULL,
    shipperid  INTEGER NOT NULL,
    productid  INTEGER NOT NULL,
    quantity   INTEGER,
    totalsold  NUMBER(10, 2)
);

CREATE TABLE products (
    productid   INTEGER NOT NULL,
    productname VARCHAR2(50),
    unitprice   NUMBER,
    category    VARCHAR2(25)
);

ALTER TABLE products ADD CONSTRAINT products_pk PRIMARY KEY ( productid );

CREATE TABLE shippers (
    shipperid   INTEGER NOT NULL,
    companyname VARCHAR2(25)
);

ALTER TABLE shippers ADD CONSTRAINT shippers_pk PRIMARY KEY ( shipperid );

CREATE TABLE stage_customers (
    customerid VARCHAR2(10),
    id         INTEGER
);

CREATE TABLE time (
    timeid INTEGER NOT NULL,
    month  VARCHAR2(2),
    year   VARCHAR2(4)
);

ALTER TABLE time ADD CONSTRAINT tiempoid_pk PRIMARY KEY ( timeid );

-- Agregar restricciones de claves foráneas
ALTER TABLE orders
    ADD CONSTRAINT orders_customers_fk FOREIGN KEY ( customerid )
        REFERENCES customers ( customerid );

ALTER TABLE orders
    ADD CONSTRAINT orders_employees_fk FOREIGN KEY ( employeeid )
        REFERENCES employees ( employeeid );

ALTER TABLE orders
    ADD CONSTRAINT orders_products_fk FOREIGN KEY ( productid )
        REFERENCES products ( productid );

ALTER TABLE orders
    ADD CONSTRAINT orders_shippers_fk FOREIGN KEY ( shipperid )
        REFERENCES shippers ( shipperid );

ALTER TABLE orders
    ADD CONSTRAINT orders_time_fk FOREIGN KEY ( timeid )
        REFERENCES time ( timeid );